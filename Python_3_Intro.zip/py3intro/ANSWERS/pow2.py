#!/usr/bin/python3

for n in range(0, 32):
	print("{0:2d} {1:10d}".format(n, 2**n))

