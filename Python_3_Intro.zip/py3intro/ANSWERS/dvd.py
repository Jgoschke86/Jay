
from media import Media

class DVD(Media):
    pass

