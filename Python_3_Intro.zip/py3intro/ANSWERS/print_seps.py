#!/usr/bin/python3

import sys
import os

print("Pathname separator: ",os.path.sep)
print("PATH separator: ",os.pathsep)
print("Extension separator: ",os.extsep)
