#!/usr/bin/python3
name = input("What is your name: ")
quest = input("What is your quest? ")
print(name,"seeks",quest)
num = int(input("Enter number: "))
print("2 times",num,"is ",2 * num)
