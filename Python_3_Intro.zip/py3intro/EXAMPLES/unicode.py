#!/usr/bin/python3
print('we spent \u20ac1.23M for an original C\u00e9zanne')
print('26\u00B0')
print('26\N{DEGREE SIGN}')
print('26\u00B0')
print(r'26\u00B0\n')
print(r'26\N{DEGREE SIGN}')
