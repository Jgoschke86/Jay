#!/usr/bin/python3

print("range(1,6): ",end=' ')
for x in range(1,6):
	print(x,end=' ')
print()

print("range(6): ", end=' ')
for x in range(6):
	print(x,end=' ')
print()

print("range(3,12): ", end=' ')
for x in range(3,12):
	print(x,end=' ')
print()

print("range(5,30,5): ", end=' ')
for x in range(5,30,5):
	print(x,end=' ')
print()

print("range(10,1,-1): ", end=' ')
for x in range(10,0,-1):
	print(x,end=' ')
print()

print("range(30,0,-5): ", end=' ')
for x in range(30,5,-5):
	print(x,end=' ')
print()


