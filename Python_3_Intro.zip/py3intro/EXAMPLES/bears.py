#!/usr/bin/env python3
# (c) 2015 John Strickler
#

bears = ['Grizzly', 'black', 'brown', 'Kodiak', 'spectacled']

def list():
    for bear in bears:
        print(bear)

