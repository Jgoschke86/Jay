#!/usr/bin/python3

from spam import *

eggs("fried")
toast("butter","strawberry jam")
