#!/usr/bin/python3
import sys

name = sys.argv[1]
print("name is",name)
