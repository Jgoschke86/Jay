
import spam

spam.eggs("fried")
spam.toast("butter","strawberry jam")
print()

help(spam)
print()

help(spam.toast)
