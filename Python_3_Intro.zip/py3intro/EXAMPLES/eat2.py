
from spam import eggs,toast

eggs("fried")
toast("butter","strawberry jam")
