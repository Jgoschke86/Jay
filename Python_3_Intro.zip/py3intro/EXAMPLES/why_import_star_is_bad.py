#!/usr/bin/env python3
# (c) 2015 John Strickler
#
from bears import *

names = list()
print("names is", names)
