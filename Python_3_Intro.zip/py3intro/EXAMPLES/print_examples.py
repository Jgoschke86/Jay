#!/usr/bin/python3

print("Hello, world")
print("#------------------------")

print("Hello,", end=' ')
print("world")
print("#------------------------")

print("Hello,", end=' ')
print("world", end ='!')
print("#------------------------")


x = "Hello"
y = "world"

print(x,y)
print("#------------------------")

print(x,y,sep=', ')
print("#------------------------")

print(x,y,sep='')
print("#------------------------")

