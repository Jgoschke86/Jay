#!/usr/bin/python3

with open("../DATA/tyger.txt","r") as F:
    for line in F:
        print(line,end='')
