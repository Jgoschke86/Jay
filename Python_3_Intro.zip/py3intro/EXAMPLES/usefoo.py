#!/usr/bin/python3

import foolib
foolib.hello()
foolib.shush()