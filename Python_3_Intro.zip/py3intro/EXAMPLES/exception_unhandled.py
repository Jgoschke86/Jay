#!/usr/bin/env python

x = 5
y = "cheese"

z = x + y
