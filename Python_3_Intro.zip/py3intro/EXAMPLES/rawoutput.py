#!/usr/bin/python3

items = ('red',3.6,'blue',8,37,'a','green')

print(''.join(str(i) for i in items))


