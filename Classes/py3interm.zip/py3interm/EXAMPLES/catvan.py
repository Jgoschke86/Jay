from animalvan import AnimalVan

class ConfuseACat(AnimalVan):
    def __init__(self):
        super().__init__('cat','confuse')
