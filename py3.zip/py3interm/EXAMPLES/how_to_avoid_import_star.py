#!/usr/bin/env python
import electrical as e  # <1>
import navigation as n  # <2>

print(e.current())  # <3>
print(n.current())  # <4>
