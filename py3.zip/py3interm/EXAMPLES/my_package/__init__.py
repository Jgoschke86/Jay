#!/usr/bin/env python

print("Loading my_package")
# __all__ = ['module_a', 'module_b']
# from my_package import module_a, module_b
