#!/usr/bin/env python
# (c) 2017 John Strickler
#
def function_b():
    print("Hello from function_b")
