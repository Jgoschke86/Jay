with open(r'DATA/presidents.txt') as p:
    
    count = {}

    for line in p:
        fields = line.split(':')
        if fields[6] in count:
            count[fields[6]] += 1
        else:
            count[fields[6]] = 1

for s, c in sorted(count.items()):
    print("%-16s %2d" % (s, c))