import calendar
from datetime import datetime as DT

d0 = [(DT(1956, 10, 31, 0, 0, 0)), (DT(1952, 9, 22, 0, 0, 0)), (DT(1990, 8, 27, 0, 0, 0))]

print(calendar.isleap(1956))

for d in d0:
    dTime = d.timetuple()

    if calendar.isleap(dTime.tm_year) == True:
        leap = "is"
    else:
        leap = "is not"
    print("{} fell on a {} and {} a leap year.".format(d.date(), calendar.day_name[dTime.tm_wday], leap))