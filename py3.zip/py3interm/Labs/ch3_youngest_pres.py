import calendar

with open(r'DATA/presidents.txt') as p:
    fields = {}
    for line in p:
        fields = line.split(':')
        for pres, year in fields:

    #print(fields)


print(fields)