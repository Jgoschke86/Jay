from ch6_potus import get_pres_info

for i in range(1-46):
    print(f"PRESIDENT: {i}")
    for field, value in get_pres_info(i).items():
        print(field, value)
    print()