with open(r'DATA/presidents.txt') as p:
    
    lastNames = []

    for line in p:
        fields = line.split(':')
        lastNames.append(fields[1])
    
    capNames = [ ln.upper() for ln in lastNames ]

print(capNames)

for n in lastNames: print(n)
