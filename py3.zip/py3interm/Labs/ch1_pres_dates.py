presName = input("Give the name of a President to see details of birth and death: ")
print('')

with open(r'DATA/presidents.txt') as p:

    for line in p:
        fields = line.split(':')
        #print(fields)
        if  fields[1].lower().startswith(presName.lower()):
            if fields[4] == "NONE":
                alive = True
                age = 2020 - int(fields[3].split('-')[0])
            else:
                alive = False
                age = int(fields[4].split('-')[0]) - int(fields[3].split('-')[0])
            
            print("NAME: {} {}".format(fields[2], fields[1]))
            print("DOB: {}".format(fields[3]))
            print("DOD: ", end='')
            if alive == True:
                print("Still kickin it at {} years old.".format(age))
            else:
                print("{} ({} years old)".format(fields[4], age))
            print('')
