import datetime

with open(r'DATA/presidents.txt') as p:
    
    presData = []

    for line in p:
        fields = line.split(':')
        presData.append([fields[2], fields[1], fields[3], fields[9]])
    
for d in presData:
    print(sorted(d, key=lambda e: e[2]))
