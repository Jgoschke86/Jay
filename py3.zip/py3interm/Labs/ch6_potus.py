from datetime import date

def mk_date(raw_date):
    if raw_date!= "NONE":
        date_year, date_month, date_day = raw_date.split('-')
        d = date(int(date_year), int(date_month), int(date_day))
    else:
        d = None
    return d

def get_pres_info(i):
    pres_data = {}
    with open(r"DATA/presidents.txt") as pres_info:
        for line in pres_info:
            pi = line[:-1].split(':')
            if int(pi[0]) == i:
                pres_data["firstName"] = pi[2]
                pres_data["lastName"] = pi[1]

                pres_data["birthDate"] = pi[3]
                pres_data["deathDate"] = pi[4]

                pres_data["birthPlace"] = pi[5]
                pres_data["birthState"] = pi[6]

                pres_data["termStart"] = pi[7]
                pres_data["termEnd"] = pi[8]

                pres_data["party"] = pi[9]

                break
    return pres_data

def get_all_info():
    all_data = []
    for i in range(1 - 46):
        all_data.append(get_pres_info(i))
    return all_data