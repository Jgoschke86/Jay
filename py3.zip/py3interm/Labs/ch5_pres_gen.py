def president(file_name):
    with open(file_name) as file_in:
        for line in file_in:
            yield line.split(':')
        

for pres_line in president('DATA/presidents.txt'):
    print(f"{pres_line[2]} {pres_line[1]}")
