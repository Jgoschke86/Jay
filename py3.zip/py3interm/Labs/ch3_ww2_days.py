from datetime import date

d0 = date(1941, 12, 7)
d1 = date(1945, 8, 15)
length = d1 - d0

print("World War II lastest for {} days.".format(length.days))